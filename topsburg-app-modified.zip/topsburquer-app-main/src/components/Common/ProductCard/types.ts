export type ProductCardProps = {
    name?: string;
    quantity?: number;
    value?: number;
    previewImage?: string;
};
import React from 'react'

//Método que altera um documento na coleção do firebase
export const putCantina = () => {

}
